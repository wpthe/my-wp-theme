<?php

namespace My_Theme;

defined( 'ABSPATH' ) || exit;
